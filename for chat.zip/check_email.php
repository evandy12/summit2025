<?php
// check_email.php - Called via AJAX to check for duplicate email

header('Content-Type: application/json');

if (!isset($_GET['email']) || empty($_GET['email'])) {
    echo json_encode(["exists" => false]);
    exit;
}

$email = strtolower(trim($_GET['email']));
$file = 'registrations.csv';

if (!file_exists($file)) {
    echo json_encode(["exists" => false]);
    exit;
}

$handle = fopen($file, 'r');
$headers = fgetcsv($handle);
$emailIndex = array_search('Email', $headers);

while (($row = fgetcsv($handle)) !== false) {
    if (strtolower(trim($row[$emailIndex])) === $email) {
        fclose($handle);
        echo json_encode(["exists" => true]);
        exit;
    }
}

fclose($handle);
echo json_encode(["exists" => false]);
?>
