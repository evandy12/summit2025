<?php
header('Content-Type: application/json');

$file = 'registrations.csv';

try {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input) || count($input) < 1) {
        throw new Exception("Invalid or empty data provided.");
    }

    $fp = fopen($file, 'w');
    if (!$fp) {
        throw new Exception("Unable to open file for writing.");
    }

    foreach ($input as $row) {
        if (!is_array($row)) {
            throw new Exception("Each row must be an array.");
        }
        fputcsv($fp, $row);
    }

    fclose($fp);

    echo json_encode(["success" => true]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
?>